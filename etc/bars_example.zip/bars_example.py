from bokeh.plotting import figure, output_server
from bokeh.document import Document
from bokeh.models import ColumnDataSource
from bokeh.client import push_session
from bokeh.io import curstate
from bokeh.models.layouts import VBox, HBox
from bokeh.models import TapTool, Range1d, LinearAxis
from bokeh.models.formatters import NumeralTickFormatter

import argparse
import datetime
import math
import threading
from math import pi
from data_access_visualization import DataAccessObjectVisualization
import calendar
import random
import sys
curstate().autoadd = False

import time

class BarPlot(object):
    def __init__(self, height, width, dao, pf_line=True, follows=False, x_cat_labels=False):
        self.dao = dao
        self.height = height
        self.width = width
        self.most_recent_ctx_data = None
        self.last_selected_index = None
        self.last_select = None
        self.pf_line = pf_line
        self.follows = follows
        self.x_cat_labels = x_cat_labels

    def prepare_ranges(self, ctx_data, initial=False):
        raise NotImplementedError('order method not defined by user')

    def get_data(self):
        raise NotImplementedError('order method not defined by user')

    def update_data(self, ctx_data, initial=False):
        try:
            rng_dat = self.prepare_ranges(ctx_data, initial=initial)

        except KeyError:
            if self.last_selected_index is not None:
                self.source.selected = {u'2d': {u'indices': []}, u'1d': {u'indices': [self.last_selected_index]}, u'0d': {u'indices': [], u'glyph': None}}
                return

        print "Update [%s]"%str(self.__class__.__name__).ljust(15), str(ctx_data)

        if 'y_range_start' in rng_dat:
            self.plot.y_range.start = rng_dat['y_range_start']
        if 'y_range_end' in rng_dat:
            self.plot.y_range.end = rng_dat['y_range_end']

        if self.x_cat_labels:
            self.plot.x_range.factors = rng_dat['x']
        else:
            if 'x_range_start' in rng_dat:
                self.plot.x_range.start = rng_dat['x_range_start']
            if 'x_range_end' in rng_dat:
                self.plot.x_range.end = rng_dat['x_range_end']
            if 'x_desired_num_ticks' in rng_dat:
                self.plot.grid[0].ticker.desired_num_ticks = rng_dat['x_desired_num_ticks']

        if self.pf_line:
            if initial:
                self.plot.extra_y_ranges = {"pf_data": Range1d(start=rng_dat['y_range_start_pf'], end=rng_dat['y_range_end_pf'])}
            else:
                self.plot.extra_y_ranges["pf_data"].start = rng_dat['y_range_start_pf']
                self.plot.extra_y_ranges["pf_data"].end = rng_dat['y_range_end_pf']

        if not initial:
            self.most_recent_ctx_data = ctx_data

        if self.x_cat_labels:
            line_source_x = [0, len(rng_dat['x']) + 0.5]
        else:
            line_source_x = [self.plot.x_range.start, self.plot.x_range.end]

        if initial:
            self.source = ColumnDataSource(data=dict(x=rng_dat['x'], x_labels=rng_dat['x_labels'], y=rng_dat['y']))
            self.line_source = ColumnDataSource(data=dict(x=line_source_x, y=[0, 0]))
            if self.pf_line:
                self.line_source_pf_data = ColumnDataSource(data=dict(x=rng_dat['x_pf'], y=rng_dat['y_pf']))
        else:
            self.source.data = dict(x=rng_dat['x'], x_labels=rng_dat['x_labels'], y=rng_dat['y'])
            self.line_source.data = dict(x=line_source_x, y=[0, 0])
            if self.pf_line:
                self.line_source_pf_data.data = dict(x=rng_dat['x_pf'], y=rng_dat['y_pf'])

        if self.follows:
            rng_dat['selected_index'] = rng_dat['last_index']

        if rng_dat['selected_index'] != self.last_selected_index:
            self.source.selected = {u'2d': {u'indices': []}, u'1d': {u'indices': [rng_dat['selected_index']]}, u'0d': {u'indices': [], u'glyph': None}}

        self.callback(self.fill_callback_data(self.source.data['x'][rng_dat['selected_index']]))
        self.last_selected_index = rng_dat['selected_index']

    def on_datasource_select(self, attr, nerd, value):
        print "Select [%s]"%str(self.__class__.__name__).ljust(15), value
        if len(value['1d']['indices']) > 0:
            self.last_selected_index = value['1d']['indices'][0]
            self.callback(self.fill_callback_data(self.source.data['x'][value['1d']['indices'][0]]))
            self.last_select = time.time()
        else:
            if self.last_selected_index is not None:
                print "-Reset [%s]"%str(self.__class__.__name__).ljust(15), {u'2d': {u'indices': []}, u'1d': {u'indices': [self.last_selected_index]}, u'0d': {u'indices': [], u'glyph': None}}
                self.source.selected = {u'2d': {u'indices': []}, u'1d': {u'indices': [self.last_selected_index]}, u'0d': {u'indices': [], u'glyph': None}}
                

    def create_figure(self, callback):
        self.callback = callback
        TOOLS = [TapTool()]
        y_range = Range1d(0, 100)
        if not self.x_cat_labels:
            x_range = Range1d(0.0, 1.0)
        else:
            x_range = ["(placeholder)"]
        self.plot = figure(y_range=y_range, x_range=x_range, height=self.height, width=self.width, tools=TOOLS)
        if self.pf_line:
            self.plot.extra_y_ranges = {"pf_data": Range1d(start=-100, end=200)}
            self.plot.add_layout(LinearAxis(y_range_name="pf_data"), 'right')
        self.update_data(None, initial=True)
        self.source.on_change('selected', self.on_datasource_select)
        self.plot.toolbar_location = None
        self.plot.xaxis.major_label_orientation = pi/4
        self.plot.yaxis[0].formatter = NumeralTickFormatter(format='0.00%')
        visible = self.plot.rect(source=self.source, x='x',y='x_labels', height='y', width=1, color='red', alpha=0.6, nonselection_alpha=0.5)
        self.plot.line(source=self.line_source, x='x', y='y', name="zero_line")
        if self.pf_line:
            self.plot.line(source=self.line_source_pf_data, x='x', y='y', name="zero_line", y_range_name="pf_data", color='green', alpha=0.5)

        return self.plot


class YearBarPlot(BarPlot):
    def __init__(self, height, width, dao, follows=False):
        super(YearBarPlot, self).__init__(height, width, dao, follows=follows)

    def get_data(self):
        return self.dao.year_data

    def fill_callback_data(self, selected_item):
        return {'year': selected_item}

    def prepare_ranges(self, ctx_data, initial=False):
        data = self.get_data()
        x = sorted(data.keys())
        y = [data[k][0] for k in x]
        x_pf = sorted(data.keys())
        y_pf = [data[k][1] for k in x]
        x_labels = [k / 2 for k in y]
        y = [math.fabs(k) for k in y]
        min_y = min(y)
        max_y = max(y)
        max_diff = max(math.fabs(min_y), math.fabs(max_y)) * 1.1

        min_y = data[x[0]][2] - min(y_pf)
        max_y = data[x[0]][2] - max(y_pf)
        max_diff_pf = max(math.fabs(min_y), math.fabs(max_y)) * 1.3

        if self.last_selected_index is None:
            selected_index = 0
        else:
            selected_index = self.last_selected_index

        last_index = len(x) - 1

        return dict(x=x,
                    y=y,
                    x_labels=x_labels,
                    selected_index=selected_index,
                    y_range_start=-max_diff,
                    y_range_end=max_diff,
                    x_range_start=min(x) - 0.5,
                    x_range_end=max(x) + 0.5,
                    x_desired_num_ticks=len(x),
                    x_pf=x_pf,
                    y_pf=y_pf,
                    y_range_start_pf=data[x[0]][2] - max_diff_pf,
                    y_range_end_pf=data[x[0]][2] + max_diff_pf,
                    last_index=last_index)


class MonthBarPlot(BarPlot):
    def __init__(self, height, width, dao, follows=False):
        super(MonthBarPlot, self).__init__(height, width, dao, follows=follows)
        self.most_recent_ctx_data = None

    def get_data(self):
        return self.dao.month_data

    def fill_callback_data(self, selected_item):
        return {'year': self.most_recent_ctx_data['year'],
                'month': selected_item}

    def prepare_ranges(self, ctx_data, initial=False):
        data = self.get_data()

        if not initial:
            year = ctx_data['year']
        else:
            year = sorted(data.keys())[0]
            self.most_recent_ctx_data = {'year': year}

        x = range(1, 13)
        y = [0.0] * 12
        x_pf = []
        y_pf = []
        selected_index = None
        last_index = None
        first_trade = None
        for month in sorted(data[year]):
            if first_trade is None:
                first_trade = data[year][month]

            if selected_index is None:
                selected_index = month - 1

            if self.last_selected_index == month - 1:
                selected_index = month - 1

            y[month - 1] = data[year][month][0]
            x_pf.append(month)
            y_pf.append(data[year][month][1])
            last_index = month - 1

        x_labels = [k / 2 for k in y]
        y = [math.fabs(k) for k in y]
        min_y = min(y)
        max_y = max(y)
        max_diff = max(math.fabs(min_y), math.fabs(max_y)) * 1.1

        min_y = first_trade[2] - min(y_pf)
        max_y = first_trade[2] - max(y_pf)
        max_diff_pf = max(math.fabs(min_y), math.fabs(max_y)) * 1.3

        return dict(x=x,
                    y=y,
                    x_labels=x_labels,
                    selected_index=selected_index,
                    y_range_start=-max_diff,
                    y_range_end=max_diff,
                    x_range_start=0.5,
                    x_range_end=12.5,
                    x_desired_num_ticks=12,
                    x_pf=x_pf,
                    y_pf=y_pf,
                    y_range_start_pf=first_trade[2] - max_diff_pf,
                    y_range_end_pf=first_trade[2] + max_diff_pf,
                    last_index=last_index)


class DayBarPlot(BarPlot):
    def __init__(self, height, width, dao, follows=False):
        super(DayBarPlot, self).__init__(height, width, dao, follows=follows)

    def get_data(self):
        return self.dao.daily_data

    def fill_callback_data(self, selected_item):
        return {'year': self.most_recent_ctx_data['year'],
                'month': self.most_recent_ctx_data['month'],
                'day': selected_item}

    def prepare_ranges(self, ctx_data, initial=False):
        data = self.get_data()
        if not initial:
            year = ctx_data['year']
            month = ctx_data['month']
        else:
            year = sorted(data.keys())[0]
            month = sorted(data[year].keys())[0]
            self.most_recent_ctx_data = {'year': year,
                                         'month': month}

        _, days_in_month = calendar.monthrange(year, month)

        x = range(1, days_in_month + 1)
        y = [0.0] * days_in_month

        x_pf = []
        y_pf = []

        first_trade = None
        selected_index = None
        last_index = None
        for day in sorted(data[year][month]):
            if first_trade is None:
                first_trade = data[year][month][day]

            if selected_index is None:
                selected_index = day - 1

            if self.last_selected_index == day - 1:
                selected_index = day - 1

            y[day - 1] = data[year][month][day][0]
            x_pf.append(day)
            y_pf.append(data[year][month][day][1])
            last_index = day - 1

        x_labels = [k / 2 for k in y]
        y = [math.fabs(k) for k in y]
        min_y = min(y)
        max_y = max(y)
        max_diff = max(math.fabs(min_y), math.fabs(max_y)) * 1.1

        min_y = first_trade[2] - min(y_pf)
        max_y = first_trade[2] - max(y_pf)
        max_diff_pf = max(math.fabs(min_y), math.fabs(max_y)) * 1.3

        return dict(x=x,
                    y=y,
                    x_labels=x_labels,
                    selected_index=selected_index,
                    y_range_start=-max_diff,
                    y_range_end=max_diff,
                    x_range_start=0.5,
                    x_range_end=days_in_month + 0.5,
                    x_desired_num_ticks=days_in_month,
                    x_pf=x_pf,
                    y_pf=y_pf,
                    y_range_start_pf=first_trade[2] - max_diff_pf,
                    y_range_end_pf=first_trade[2] + max_diff_pf,
                    last_index=last_index)


class NameBarPlot(BarPlot):
    def __init__(self, height, width, dao, follows=False):
        super(NameBarPlot, self).__init__(height, width, dao,
                                            pf_line=False, follows=follows, x_cat_labels=True)

    def get_data(self):
        return self.dao.daily_data_per_name, self.dao.daily_data

    def fill_callback_data(self, selected_item):
        return {'year': self.most_recent_ctx_data['year'],
                'month': self.most_recent_ctx_data['month'],
                'day': selected_item}

    def prepare_ranges(self, ctx_data, initial=False):
        data, daily_data = self.get_data()
        if not initial:
            year = ctx_data['year']
            month = ctx_data['month']
            day = ctx_data['day']

        else:
            year = sorted(data.keys())[0]
            month = sorted(data[year].keys())[0]
            day = sorted(data[year][month].keys())[0]
            self.most_recent_ctx_data = {'year': year,
                                         'month': month,
                                         'day': day}

        last_day_pf_value = daily_data[year][month][day][2]
        data = data[year][month][day]
        x = []
        y = []
        i = 0

        selected_index = None
        last_index = None
        for s in sorted(data.keys()):
            if selected_index is None:
                selected_index = i

            if self.last_selected_index == i:
                selected_index = i

            x.append(s)
            y.append(data[s][0] / last_day_pf_value)
            i += 1

        x_labels = [k / 2 for k in y]
        y = [math.fabs(k) for k in y]
        min_y = min(y)
        max_y = max(y)
        max_diff = max(math.fabs(min_y), math.fabs(max_y)) * 1.1

        return dict(x=x,
                    y=y,
                    x_labels=x_labels,
                    selected_index=selected_index,
                    y_range_start=-max_diff,
                    y_range_end=max_diff,
                    x_range_start=-0.5,
                    x_range_end=len(x) + 0.5,
                    x_desired_num_ticks=len(x),
                    last_index=selected_index)


def print_selection(ctx_data, initial=False):
    pass


def datetime_bars(start_dt, end_dt, step_seconds):
    while start_dt < end_dt:
        yield start_dt
        start_dt += datetime.timedelta(seconds=step_seconds)


def fill_dao(init_val, value, start_dt, end_dt, dao, order_id, down):

    for dt_entry in datetime_bars(start_dt, end_dt, 5):
        for s in ["test1", "test2", "test3", "test4"]:
            if random.random() < 0.001:
                if down:
                    value = value * 0.9992
                    if value < 0.95 * init_val:
                        down = False
                else:
                    value = value * 1.0007
                    if value > 1.05 * init_val:
                        down = True

                dao.insert_data(dt_entry, s, value, random.randint(1, 10), order_id)
                order_id += 1

    return value, order_id, down


class Testplot(object):
    def __init__(self, dao):
        self.data_dao = dao
        self.document = Document()
        self.follows = True
        self.year_plot = YearBarPlot(300, 200, self.data_dao, follows=self.follows)
        self.month_plot = MonthBarPlot(300, 400, self.data_dao, follows=self.follows)
        self.day_plot = DayBarPlot(300, 800, self.data_dao, follows=self.follows)
        self.name_plot = NameBarPlot(300, 200, self.data_dao, follows=self.follows)

        # this needs to be done in exactly this order
        name_figure = self.name_plot.create_figure(print_selection)
        day_figure = self.day_plot.create_figure(self.name_plot.update_data)
        month_figure = self.month_plot.create_figure(self.day_plot.update_data)
        year_figure = self.year_plot.create_figure(self.month_plot.update_data)

        horizontal_box_top = HBox(children=[year_figure, month_figure, day_figure, name_figure])
        horizontal_box_bot = HBox(children=[])
        self.layout = VBox(children=[horizontal_box_top, horizontal_box_bot])
        self.document.add_root(self.layout)

        #self.session = push_session(self.document, app_path='/bokeh_utils')
        self.session = push_session(self.document)
        output_server("example.html")
        self.session.show()
        x = threading.Thread(target=self.session.loop_until_closed)
        x.daemon = True
        x.start()




def main():
    parser = argparse.ArgumentParser(description='This program calculates the ea clusters')
    parser.add_argument('--follow', action='store_true', help='file in libsvm format')
    args = parser.parse_args()
    
    random.seed(3)
    init_value = 50000
    value = init_value
    order_id = 0
    data_dao = DataAccessObjectVisualization(value)
    value, order_id, down = fill_dao(init_value, value,
                                     datetime.datetime(year=2014,
                                                       month=11,
                                                       day=15,
                                                       hour=6),
                                     datetime.datetime(year=2015,
                                                       month=03,
                                                       day=15),
                                     data_dao, order_id, True)

    x = Testplot(data_dao)
    
    if args.follow:
        old_date = datetime.datetime(year=2015, month=03, day=16)
        for i in range(1000):
            time.sleep(0.5)
            new_date = old_date + datetime.timedelta(days=1)
            value, order_id, down = fill_dao(init_value, value, old_date, new_date, data_dao, order_id, down)
            x.year_plot.update_data(None)
            old_date = new_date
    
    time.sleep(500)
    
if __name__ == '__main__':
    sys.exit(main())
