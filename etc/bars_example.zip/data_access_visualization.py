import math

class DataAccessObjectVisualization(object):

    def __init__(self, initial_amount):
        self.data = {}
        self.initial_amount = initial_amount
        self.year_data = {}
        self.month_data = {}
        self.daily_data = {}
        self.daily_data_per_name = {}
        self.last_year_amount = initial_amount
        self.last_month_amount = initial_amount
        self.last_day_amount = initial_amount
        self.last_pf_value = initial_amount
        self.current_year = None
        self.current_month = None
        self.current_day = None

    def insert_data(self, dt_entry, name, pf_value, size, order_id):
        dt_utc = dt_entry
        year = dt_utc.year
        month = dt_utc.month
        day = dt_utc.day

        if year not in self.year_data:
            if self.current_year is not None:
                self.last_year_amount = self.year_data[self.current_year][1]

            self.month_data[year] = {}
            self.daily_data[year] = {}
            self.daily_data_per_name[year] = {}

        if month not in self.month_data[year]:
            if self.current_month is not None:
                self.last_month_amount = self.month_data[self.current_year][self.current_month][1]

            self.daily_data[year][month] = {}
            self.daily_data_per_name[year][month] = {}

        if day not in self.daily_data[year][month]:
            if self.current_day is not None:
                self.last_day_amount = self.daily_data[self.current_year][self.current_month][self.current_day][1]

            self.daily_data_per_name[year][month][day] = {}
            #print year, month, day, self.last_year_amount, self.last_month_amount, self.last_day_amount


        self.current_year = year
        self.current_month = month
        self.current_day = day

        self.year_data[self.current_year] = ((pf_value - self.last_year_amount)
                                             / self.last_year_amount,
                                             pf_value, self.last_year_amount)
        self.month_data[year][self.current_month] = ((pf_value - self.last_month_amount)
                                                     / self.last_month_amount,
                                                     pf_value, self.last_month_amount)
        self.daily_data[year][month][self.current_day] = ((pf_value - self.last_day_amount)
                                                          / self.last_day_amount,
                                                          pf_value, self.last_day_amount)

        this_daily_data = self.daily_data_per_name[year][month][day]
        if name not in this_daily_data:
            this_daily_data[name] = [0, {}]

        this_daily_data[name][0] += pf_value - self.last_pf_value
        this_daily_data[name][1][dt_utc] = (pf_value, size, pf_value / size, order_id)
        self.last_pf_value = pf_value
